DROP TABLE IF EXISTS #__odai_vdbs;

DROP TABLE IF EXISTS #__odai_resources;

DROP TABLE IF EXISTS #__odai_datasources;

DROP TABLE IF EXISTS #__odai_apis;
